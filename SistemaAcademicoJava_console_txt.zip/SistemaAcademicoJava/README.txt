SISTEMA ACADÊMICO SIMPLIFICADO - JAVA / POO

Como executar no IntelliJ IDEA:
1. Abra a pasta do projeto no IntelliJ.
2. Abra src/Main.java.
3. Clique no botão Run (triângulo verde) ao lado de main.
4. Digite as respostas diretamente no painel Run/Console, na parte inferior do IntelliJ, e pressione Enter após cada resposta.

O programa pede:
- Nome do aluno
- Nome do curso
- Preço do curso
- Política de desconto
- Formato do comprovante

Ao terminar, cria o arquivo dados_matricula.txt no diretório de trabalho (normalmente a pasta do projeto configurada no IntelliJ).
O arquivo contém nome do aluno, curso, preço original, desconto aplicado, valor final e comprovante.

Também demonstra:
- Singleton: Configuracao
- Strategy: políticas de desconto
- Observer: notificações de matrícula
- Adapter: conversão de reais em centavos
- Factory Method: criação de comprovantes
- Facade: coordenação da matrícula
