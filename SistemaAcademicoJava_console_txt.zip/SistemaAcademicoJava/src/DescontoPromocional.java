public class DescontoPromocional implements Desconto {
    @Override
    public double aplicar(double valor) {
        // Exemplo de uma promoção de 20%.
        return valor * 0.80;
    }
}
