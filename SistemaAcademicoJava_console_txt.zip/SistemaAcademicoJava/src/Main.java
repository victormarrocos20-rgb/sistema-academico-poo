import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        try {
            System.out.println("=== Sistema Acadêmico ===");

            System.out.print("Digite o nome do aluno: ");
            String nomeAluno = entrada.nextLine().trim();

            System.out.print("Digite o nome do curso: ");
            String nomeCurso = entrada.nextLine().trim();

            double precoCurso = lerValor(entrada, "Digite o preço do curso (ex.: 200,00): ");

            System.out.println();
            System.out.println("Escolha a política de desconto:");
            System.out.println("1 - Sem desconto");
            System.out.println("2 - Desconto estudantil (10%)");
            System.out.println("3 - Desconto promocional (20%)");
            int opcaoDesconto = lerInteiro(entrada, "Opção: ");

            Desconto politica;
            String nomeDesconto;
            if (opcaoDesconto == 1) {
                politica = new SemDesconto();
                nomeDesconto = "Sem desconto";
            } else if (opcaoDesconto == 3) {
                politica = new DescontoPromocional();
                nomeDesconto = "Desconto promocional (20%)";
            } else {
                if (opcaoDesconto != 2) {
                    System.out.println("Opção inválida. Será usado o desconto estudantil.");
                }
                politica = new DescontoEstudante();
                nomeDesconto = "Desconto estudantil (10%)";
            }

            System.out.println();
            System.out.println("Escolha o formato do comprovante:");
            System.out.println("1 - Completo");
            System.out.println("2 - Resumido");
            int opcaoComprovante = lerInteiro(entrada, "Opção: ");

            CriadorComprovante criador;
            String formatoComprovante;
            if (opcaoComprovante == 2) {
                criador = new CriadorResumido();
                formatoComprovante = "Resumido";
            } else {
                criador = new CriadorTexto();
                formatoComprovante = "Completo";
            }

            Aluno aluno = new Aluno(nomeAluno);
            Curso curso = new Curso(nomeCurso, precoCurso);

            SistemaLegado sistemaAntigo = new SistemaLegado();
            RegistradorPagamento pagamento = new AdaptadorPagamento(sistemaAntigo);
            ServicoMatricula servico = new ServicoMatricula(politica, pagamento);

            servico.inscrever(new AvisoEmail());
            servico.inscrever(new Auditoria());
            servico.inscrever(new Estoque());
            servico.inscrever(new Financeiro());

            FachadaAcademica fachada = new FachadaAcademica(servico, criador);
            String comprovante = fachada.matricularEEmitir(aluno, curso);
            double total = politica.aplicar(precoCurso);

            String dados = montarArquivo(nomeAluno, nomeCurso, precoCurso, nomeDesconto,
                    total, formatoComprovante, comprovante);

            Path arquivo = Path.of("dados_matricula.txt");
            Files.writeString(arquivo, dados, StandardCharsets.UTF_8);

            System.out.println();
            System.out.println("=== Resultado ===");
            System.out.println(comprovante);
            System.out.println("Cursos cadastrados para o aluno: " + aluno.getQuantidadeCursos());
            System.out.println("Os dados foram salvos em: " + arquivo.toAbsolutePath());

        } catch (IllegalArgumentException e) {
            System.out.println("Erro nos dados informados: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Não foi possível salvar o arquivo TXT: " + e.getMessage());
        } finally {
            entrada.close();
        }
    }

    private static double lerValor(Scanner entrada, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String texto = entrada.nextLine().trim().replace(",", ".");
            try {
                double valor = Double.parseDouble(texto);
                if (valor > 0) {
                    return valor;
                }
            } catch (NumberFormatException e) {
                // Solicita novamente se o valor não for numérico.
            }
            System.out.println("Valor inválido. Digite um valor maior que zero, como 200,00.");
        }
    }

    private static int lerInteiro(Scanner entrada, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String texto = entrada.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException e) {
                System.out.println("Opção inválida. Digite o número indicado.");
            }
        }
    }

    private static String montarArquivo(String nomeAluno, String nomeCurso,
                                        double preco, String desconto, double total,
                                        String formato, String comprovante) {
        return "DADOS DA MATRÍCULA" + System.lineSeparator()
                + "Aluno: " + nomeAluno + System.lineSeparator()
                + "Curso: " + nomeCurso + System.lineSeparator()
                + String.format(java.util.Locale.forLanguageTag("pt-BR"),
                        "Preço original: R$ %.2f%n", preco)
                + "Desconto aplicado: " + desconto + System.lineSeparator()
                + String.format(java.util.Locale.forLanguageTag("pt-BR"),
                        "Valor final: R$ %.2f%n", total)
                + "Formato do comprovante: " + formato + System.lineSeparator()
                + "Comprovante: " + comprovante + System.lineSeparator();
    }
}
