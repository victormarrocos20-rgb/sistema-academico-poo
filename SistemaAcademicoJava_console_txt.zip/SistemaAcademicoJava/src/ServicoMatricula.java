import java.util.ArrayList;
import java.util.List;

public class ServicoMatricula {
    private final Desconto desconto;
    private final RegistradorPagamento pagamento;
    private final List<ObservadorMatricula> observadores = new ArrayList<>();

    public ServicoMatricula(Desconto desconto, RegistradorPagamento pagamento) {
        this.desconto = desconto;
        this.pagamento = pagamento;
    }

    public void inscrever(ObservadorMatricula observador) {
        if (observador != null) {
            observadores.add(observador);
        }
    }

    public double matricular(Aluno aluno, Curso curso) {
        double total = desconto.aplicar(curso.getPreco());

        pagamento.registrar(total);
        aluno.adicionarCurso(curso);

        String mensagem = aluno.getNome() + " matriculado em " + curso.getTitulo();
        for (ObservadorMatricula observador : observadores) {
            observador.atualizar(mensagem);
        }

        return total;
    }
}
