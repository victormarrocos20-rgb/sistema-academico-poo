public class Financeiro implements ObservadorMatricula {
    @Override
    public void atualizar(String mensagem) {
        System.out.println("Financeiro recebeu: " + mensagem);
    }
}
