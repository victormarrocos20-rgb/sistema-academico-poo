public class DescontoEstudante implements Desconto {
    @Override
    public double aplicar(double valor) {
        // O desconto de estudante é de 10%.
        return valor * 0.90;
    }
}
