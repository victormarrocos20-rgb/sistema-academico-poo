public final class Configuracao {
    private static final Configuracao INSTANCIA = new Configuracao();
    private final String nome = "Sistema Acadêmico";

    private Configuracao() {
        // O construtor fica privado para não criar outras instâncias.
    }

    public static Configuracao getInstancia() {
        return INSTANCIA;
    }

    public String getNome() {
        return nome;
    }
}
