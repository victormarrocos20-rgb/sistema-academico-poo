public class Estoque implements ObservadorMatricula {
    @Override
    public void atualizar(String mensagem) {
        System.out.println("Estoque atualizado: " + mensagem);
    }
}
